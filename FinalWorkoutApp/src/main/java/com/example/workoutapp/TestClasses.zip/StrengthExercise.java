package com.example.workoutapp;
import javafx.beans.property.*;
import java.lang.Double;

public class StrengthExercise extends Exercise { // child of exercise
    // fields
    public StrengthExercise(String name, double weight, int sets, int reps, String notes) {
        super(name, weight, sets, reps, notes);
        setFifthColumn(calculateSixthColumn());
        setSixthColumn(calculateFifthColumn());
    }

    //abstract methods to calculate columns
    @Override //calculate volume (sets * reps * weight used)
    public double calculateFifthColumn(){
        return getThirdColumn() * getFourthColumn() * getSecondColumn();
    }
    @Override//calculate intensity aka one rep max (epley: 1RM = weight * (reps / 30))
    public double calculateSixthColumn(){
        return getSecondColumn() * (1 + (getFourthColumn() / 30.0));
    }


}