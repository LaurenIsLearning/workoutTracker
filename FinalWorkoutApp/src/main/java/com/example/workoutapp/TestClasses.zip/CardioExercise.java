package com.example.workoutapp;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class CardioExercise extends Exercise { // child of exercise
    public CardioExercise(String name, double incline, int level, int time, String notes) {
        super(name, incline, level, time, notes);
        setFifthColumn(calculateSixthColumn());
        setSixthColumn(calculateFifthColumn());
    }

    //abstract methods to calculate columns
    @Override//calculate distance (speed * time)
    public double calculateFifthColumn(){
        return getThirdColumn() * getFourthColumn() * getSecondColumn();
    }
    @Override//calculate pace (time / distance)
    public double calculateSixthColumn(){
        return getThirdColumn() / getFifthColumn();
    }
}